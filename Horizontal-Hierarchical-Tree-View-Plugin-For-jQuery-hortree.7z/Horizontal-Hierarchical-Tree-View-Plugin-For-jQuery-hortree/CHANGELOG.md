# Change Log
All notable changes to [this project](https://github.com/alesmit/jquery-hortree) will be documented in this file.

## [1.0.1] - 2017-03-22
### Added
- Now using [gulp](http://gulpjs.com/) as build system
- Optional tooltip for each element